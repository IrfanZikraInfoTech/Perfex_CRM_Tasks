<?php

namespace Mpdf\Tag;

class Code extends InlineTag
{


}
