<?php

namespace Mpdf\Http\Exception;

class RequestException extends \Mpdf\MpdfException
{

}
