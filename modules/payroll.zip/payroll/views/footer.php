
<?php init_tail(); ?>

</body>
</html>