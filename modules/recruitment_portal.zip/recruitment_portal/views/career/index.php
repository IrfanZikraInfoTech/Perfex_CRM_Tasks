<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Careers</title>
    <!-- Include Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <style>
        .active {
            transform: scale(1.1, 1.1) !important;
            background: #0284c7 !important;
            color: white !important;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto md:px-4 md:py-8 p-2">
        <div class="text-center mb-12">
            <!-- Replace 'your_logo.png' with your company's logo file -->
            <a href="<?= base_url("career") ?>"><img src="https://ansara23.sg-host.com/wp-content/uploads/2023/07/zikra-infotech-logo-2-2048x706.png" alt="Company Logo" class="mx-auto mb-4 w-64"></a>


            <h1 class="text-4xl font-semibold">Careers</h1>

            <div class="flex justify-center mt-10 mr-4">
                <form action="<?= admin_url('recruitment_portal/career') ?>" method="GET" class="flex items-center bg-white rounded-full shadow-lg">
                    <div class="p-2">
                        <svg class="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-6a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                    <input type="text" name="filter_title" placeholder="Filter by Title" class="w-full py-2 pr-4 pl-2 rounded-full focus:outline-none focus:border-blue-300" value="<?php echo ($filter_title) ? htmlspecialchars($filter_title) : ''; ?>" >
                    <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-full">
                        Filter
                    </button>
                </form>
            </div>

        </div>
        <?php if(empty($activeCampaigns)){?>
            <h2 class="text-center text-lg text-bold">Opportunities coming soon!</h2>
        <?php } else {?>
            

            <div class="flex flex-wrap gap-4 mb-8 justify-center">
                <span class="inline-block capitalize w-32 text-center bg-white rounded-full px-4 py-2 text-md font-semibold text-sky-600 border border-sky-600 cursor-pointer transition-all ease-in-out duration-300 transform hover:scale-105 hover:bg-sky-600 hover:text-white tag-filter active" data-tag="all">
                    All
                </span>
                <?php foreach($uniqueTags as $tag): ?>
                    <span class="inline-block capitalize text-center bg-white rounded-full px-4 py-2 text-md font-semibold text-sky-600 border border-sky-600 cursor-pointer transition-all ease-in-out duration-300 transform hover:scale-105 hover:bg-sky-600 hover:text-white tag-filter" data-tag="<?= trim($tag) ?>">
                        <?= trim($tag) ?>
                    </span>
                <?php endforeach; ?>
            </div>

            <div class="grid grid-cols-1 gap-8 md:p-8 p-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-2 2xl:grid-cols-3">
                <?php foreach ($activeCampaigns as $campaign): ?>
                    <!-- <div class="flex rounded-lg shadow-lg overflow-hidden transform transition-transform duration-500 hover:scale-105 group"> -->
                    <div class="flex rounded-lg shadow-lg overflow-hidden transform transition-transform duration-500 hover:scale-105 group card" data-tags="<?= $campaign->camp_tag ?>">

                        <a href="<?= base_url("career/view/".$campaign->id) ?>" class="bg-sky-600 group-hover:bg-white border-sky-600 group-hover:border w-2/5 p-4 rounded-l-lg transition-all ease-in-out">
                            <h2 class="text-2xl text-white group-hover:text-sky-600 font-bold transition-all ease-in-out"><?php echo $campaign->title; ?></h2>
                            <p class="text-white text-opacity-70 group-hover:text-sky-400 transition-all ease-in-out"><?php echo $campaign->position; ?></p>
                        </a>
                        <div class="flex flex-col w-full h-full">
                        <a href="<?= base_url("career/view/".$campaign->id) ?>" class="h-full group-hover:bg-sky-600 w-3/5 px-6 pt-6 pb-3 bg-white flex flex-col transition-all ease-in-out w-full">
                        <?php if (isset($campaign->job_type)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-2 transition-all ease-in-out"><strong>Type:</strong> <?php echo $campaign->job_type; ?></p>
                        <?php endif; ?>

                        <?php if (isset($campaign->experience)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-2 transition-all ease-in-out"><strong>Experience:</strong> <?php echo $campaign->experience; ?></p>
                        <?php endif; ?>

                        <?php if (isset($campaign->skills_required)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-2 transition-all ease-in-out">
                                <strong>Skills:</strong>
                                <?php
                                    $skills = explode(',', $campaign->skills_required);
                                    $count = count($skills);
                                    if ($count > 3) {
                                        echo implode(',', array_slice($skills, 0, 3)) . '... and ' . ($count - 3) . ' more';
                                    } else {
                                        echo $campaign->skills_required;
                                    }
                                ?>
                            </p>
                        <?php endif; ?>


                        <?php if (isset($campaign->end_date)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-2 transition-all ease-in-out"><strong>End Date:</strong> <?php echo $campaign->end_date; ?></p>
                        <?php endif; ?>

                        <?php if (isset($campaign->salary)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-2 transition-all ease-in-out"><strong>Salary:</strong> <?php echo $campaign->salary; ?></p>
                        <?php endif; ?>

                        <?php if (isset($campaign->description)): ?>
                            <p class="text-gray-600 group-hover:text-gray-200 mb-4 transition-all ease-in-out"><?php echo $campaign->description; ?></p>
                        <?php endif; ?>
                        </a>
                        <div class="mt-auto p-4 bg-white"> 
                            <a href="<?php echo site_url('career/apply/'.$campaign->id); ?>" class="inline-block bg-yellow-500 text-white font-semibold px-6 py-2 rounded transition-colors duration-200 hover:bg-yellow-600 w-full text-center transition-all ease-in-out">Apply</a>
                        </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php } ?>
    </div>
    <!-- Begin Footer -->
    <footer class="bg-gray-200 text-gray-800 mt-16 py-2">

            <div class="flex flex-wrap justify-center">
                    <div class="p-2">Careers | <a href="https://zikrainfotech.com">Zikra Infotech LLC</a></div>
            </div>

    </footer>
    <!-- End Footer -->

    <script>

$(document).ready(function(){
    $('.tag-filter').on('click', function(){
        $('.tag-filter').removeClass('active');
        $(this).addClass('active');
        var selectedTag = $(this).data('tag');

        if (selectedTag === 'all') {
            // If 'All' is selected, show all cards with fade-in effect
            $('.card').fadeIn(400);
        } else {
            // Loop through each card and fade them out initially
            $('.card').each(function(){
                $(this).fadeOut(200);
            });
            
            // After a short delay, execute the tag filtering
            setTimeout(function() {
                $('.card').each(function(){
                    var cardTags = $(this).data('tags').split(',');

                    // Check if the card has the selected tag
                    if ($.inArray(selectedTag, cardTags) !== -1) {
                        // Show the card with a fade-in effect
                        $(this).fadeIn(400);
                    }
                });
            }, 200);  // 200ms delay to sync with fadeOut()
        }
    });
});
</script>
</body>
</html>


