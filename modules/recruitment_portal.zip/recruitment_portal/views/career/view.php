<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $campaign->title ?></title>
    <!-- Include Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="text-center mb-12">
            <!-- Replace 'your_logo.png' with your company's logo file -->
            <a href="<?= base_url("career") ?>"><img src="https://ansara23.sg-host.com/wp-content/uploads/2023/07/zikra-infotech-logo-2-2048x706.png" alt="Company Logo" class="mx-auto mb-4 w-64"></a>
            <h1 class="text-3xl font-semibold mb-2"><?php echo isset($campaign->title) ? $campaign->title : 'Job Title'; ?></h1>
            <h3 class="text-lg text-gray-600 mb-2"><?php echo isset($campaign->position) ? $campaign->position : 'Job Position'; ?></h3>
            <p class="text-gray-400 text-sm mt-3 capitalize"><?php echo isset($campaign->job_type) ? str_replace('_', ' ', $campaign->job_type) : 'Job Type'; ?></p>
        </div>

        <div class="flex flex-col md:flex-row md:space-x-6">
            <!-- Left Side -->
            <div class="w-full md:w-1/3 h-64 sticky top-4">
                <!-- Job Information -->
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg text-gray-900 mb-3">Job Information</h3>
                    <p class="text-md text-gray-700 mb-2"><strong>Start Date:</strong> <?php echo isset($campaign->start_date) ? date('jS F, Y', strtotime($campaign->start_date)) : 'Not Specified'; ?></p>
                    <p class="text-md text-gray-700 mb-2"><strong>End Date:</strong> <?php echo (isset($campaign->end_date) && $campaign->end_date != '0000-00-00') ? date('jS F, Y', strtotime($campaign->end_date)) : 'Not Specified'; ?></p>
                    <p class="text-md text-gray-700 mb-2"><strong>Salary:</strong> <?php echo isset($campaign->salary) ? $campaign->salary : 'Not Specified'; ?></p>
                    <p class="text-md text-gray-700 mb-2"><strong>Experience:</strong> <?php echo isset($campaign->experience) ? $campaign->experience : 'Not Specified'; ?></p>
                    <!-- Apply Now Button -->
                    <div class="mt-6">
                        <a href="<?php echo site_url('career/apply/'.(isset($campaign->id) ? $campaign->id : '')); ?>" class="inline-block bg-yellow-500 text-white font-semibold px-6 py-3 rounded transition-colors duration-200 hover:bg-yellow-600 w-full text-center">Apply Now</a>
                    </div>
                </div>
            </div>
            <!-- Right Side -->
            <div class="w-full md:w-2/3">
                <!-- Job Description -->
                <div class="bg-white rounded-lg p-6 shadow-sm mb-6">
                    <h3 class="text-lg text-gray-900 mb-3">Job Description</h3>
                    <p class="text-md leading-relaxed text-gray-700"><?php echo isset($campaign->detailed_description) ? $campaign->detailed_description : 'No job description provided.'; ?></p>
                </div>
                <!-- Skills Required -->
                <div class="bg-white rounded-lg p-6 shadow-sm">
                    <h3 class="text-lg text-gray-900 mb-3">Skills Required</h3>
                    <p class="text-md leading-relaxed text-gray-700"><?php echo isset($campaign->skills_required) ? $campaign->skills_required : 'No specific skills required.'; ?></p>
                </div>
            </div>
        </div>
    </div>
</body>


</html>
